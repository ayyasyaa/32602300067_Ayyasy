<h2>Edit Data Mahasiswa</h2>

<form action="/mahasiswa/update" method="post">
    <input type="hidden" name="nim" value="<?= $mahasiswa->nim ?>">

    <label>Nama:</label><br>
    <input type="text" name="nama" value="<?= $mahasiswa->nama ?>"><br><br>

    <label>Program Studi:</label><br>
    <input type="text" name="prodi" value="<?= $mahasiswa->prodi ?>"><br><br>

    <button type="submit">Update</button>
</form>
