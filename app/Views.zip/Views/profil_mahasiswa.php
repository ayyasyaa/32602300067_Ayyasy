<!DOCTYPE html>
<html>
<head>
    <title>Profil Mahasiswa</title>
    <link rel="stylesheet" type="text/css" href="<?= base_url('css/style.css') ?>">
</head>
<body>

    <h1>Profil Mahasiswa</h1>

    <ul>
        <li>Nama Lengkap: Ayyasy Abdul Aziz</li>
        <li>NIM: 32602300067</li>
        <li>Program Studi: Teknik Informatika</li>
    </ul>

</body>
</html>
