<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Profil Saya</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script>
    function enableEdit() {
      document.querySelectorAll('#profilForm input, #profilForm textarea, #profilForm select').forEach(el => {
        el.removeAttribute('readonly');
        el.removeAttribute('disabled');
      });
      document.getElementById('editBtn').classList.add('d-none');
      document.getElementById('saveBtn').classList.remove('d-none');
    }
  </script>
</head>
<body class="bg-light">

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-7">
      <h4 class="mb-4">Profil Saya</h4>

      <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
      <?php endif; ?>

      <?php if (!empty($profil->photo)): ?>
        <div class="text-center mb-4">
          <img src="<?= base_url('uploads/' . $profil->photo) ?>" alt="Foto Profil" class="rounded-circle" width="120" height="120">
        </div>
      <?php endif; ?>

      <form action="/profilku" method="post" enctype="multipart/form-data" id="profilForm">
        <?= csrf_field() ?>

        <div class="mb-3">
          <label>Email</label>
          <input type="email" name="email" class="form-control" value="<?= esc($email) ?>" readonly>
        </div>

        <div class="mb-3">
          <label>NIM</label>
          <input type="text" name="nim" class="form-control" value="<?= esc($profil->nim ?? '') ?>" <?= $profil ? 'readonly' : '' ?>>
        </div>

        <div class="mb-3">
          <label>Nama Lengkap</label>
          <input type="text" name="nama_lengkap" class="form-control" value="<?= esc($profil->nama_lengkap ?? '') ?>" <?= $profil ? 'readonly' : '' ?>>
        </div>

        <div class="mb-3">
          <label>Prodi</label>
          <input type="text" name="prodi" class="form-control" value="<?= esc($profil->prodi ?? '') ?>" <?= $profil ? 'readonly' : '' ?>>
        </div>

        <div class="mb-3">
          <label>Alamat</label>
          <textarea name="alamat" class="form-control" <?= $profil ? 'readonly' : '' ?>><?= esc($profil->alamat ?? '') ?></textarea>
        </div>

        <div class="mb-3">
          <label>Tanggal Lahir</label>
          <input type="date" name="tanggal_lahir" class="form-control" value="<?= esc($profil->tanggal_lahir ?? '') ?>" <?= $profil ? 'readonly' : '' ?>>
        </div>

        <div class="mb-3">
          <label>No HP</label>
          <input type="text" name="no_hp" class="form-control" value="<?= esc($profil->no_hp ?? '') ?>" <?= $profil ? 'readonly' : '' ?>>
        </div>

        <div class="mb-3">
          <label>Foto Profil</label>
          <input type="file" name="photo" class="form-control" <?= $profil ? 'disabled' : '' ?>>
        </div>

        <button type="submit" id="saveBtn" class="btn btn-success w-100 <?= $profil ? 'd-none' : '' ?>">Simpan Profil</button>
        <button type="button" id="editBtn" class="btn btn-warning w-100 <?= $profil ? '' : 'd-none' ?>" onclick="enableEdit()">Edit Profil</button>
      </form>
    </div>
  </div>
</div>

</body>
</html>
