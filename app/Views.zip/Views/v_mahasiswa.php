<?php
$userRole = $role ?? 'user';
$userId = $user_id ?? null;
$isAdmin = $userRole === 'admin';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary">Daftar Mahasiswa</h2>
        <a href="/profilku" class="btn btn-outline-primary">Profil Saya</a>
    </div>


    <?php if ($isAdmin): ?>
        <a href="/form" class="btn btn-success mb-3">Tambah Data Baru</a>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>NIM</th>
                <th>Nama</th>
                <th>Program Studi</th>
                <?php if ($isAdmin): ?>
                    <th>Aksi</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($mahasiswa)): ?>
                <?php foreach ($mahasiswa as $m): ?>
                    <tr>
                        <td><?= $m->nim ?></td>
                        <td><?= $m->nama ?></td>
                        <td><?= $m->prodi ?></td>
                        <?php if ($isAdmin): ?>
                        <td>
                            <div class="d-flex gap-2">
                                <a href="/mahasiswa/edit/<?= $m->nim ?>" class="btn btn-warning btn-sm">Edit</a>
                                <button class="btn btn-danger btn-sm" onclick="confirmDelete('<?= $m->nim ?>', '<?= $m->nama ?>')">Delete</button>
                            </div>
                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="<?= $isAdmin ? 4 : 3 ?>" class="text-center">Data mahasiswa belum tersedia.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Modal Bootstrap -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" id="deleteForm">
      <input type="hidden" name="_method" value="delete">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title text-danger" id="deleteModalLabel">Konfirmasi Hapus</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body" id="deleteMessage">
          Yakin ingin menghapus?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-danger">Ya, Hapus</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
function confirmDelete(nim, nama) {
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    const form = document.getElementById('deleteForm');
    const msg = document.getElementById('deleteMessage');

    msg.innerText = `Yakin ingin menghapus data mahasiswa dengan NIM ${nim} (${nama})?`;
    form.action = `/mahasiswa/delete/${nim}`;

    modal.show();
}
</script>

</body>
</html>
