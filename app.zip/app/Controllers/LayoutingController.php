<?php

namespace App\Controllers;

class LayoutingController extends BaseController
{
    public function index(): string
    {
        return view('Ayyasy_32602300067');
    }
}
