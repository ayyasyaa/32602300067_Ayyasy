<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<h2>Profil Saya</h2>
<p>Nama: Ayyasy Abdul Aziz</p>
<p>Mahasiswa jurusan Teknik Informatika yang menyukai pengembangan web dan blockchain.</p>

<?= $this->endSection() ?>


