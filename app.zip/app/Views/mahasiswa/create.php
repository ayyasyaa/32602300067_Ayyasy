<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>
<h1>Tambah Mahasiswa</h1>
<form action="/mahasiswa/store" method="post">
  <label>NIM</label><input type="text" name="nim"><br>
  <label>Nama</label><input type="text" name="nama"><br>
  <label>Prodi</label><input type="text" name="prodi"><br>
  <label>Universitas</label><input type="text" name="universitas"><br>
  <label>No HP</label><input type="text" name="no_hp"><br>
  <button type="submit">Simpan</button>
</form>
<?= $this->endSection(); ?>