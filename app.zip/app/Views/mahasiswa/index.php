<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>
<h1>Data Mahasiswa</h1>
<a href="/mahasiswa/create">Tambah Data</a>
<table border="1" cellpadding="5">
  <thead>
    <tr>
      <th>ID</th>
      <th>NIM</th>
      <th>Nama</th>
      <th>Prodi</th>
      <th>Universitas</th>
      <th>No HP</th>
      <th>Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($mahasiswa as $m): ?>
    <tr>
      <td><?= $m['id']; ?></td>
      <td><?= $m['nim']; ?></td>
      <td><?= $m['nama']; ?></td>
      <td><?= $m['prodi']; ?></td>
      <td><?= $m['universitas']; ?></td>
      <td><?= $m['no_hp']; ?></td>
      <td>
        <a href="/mahasiswa/edit/<?= $m['id']; ?>">Edit</a> |
        <a href="/mahasiswa/delete/<?= $m['id']; ?>" onclick="return confirm('Hapus data?')">Hapus</a>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<?= $this->endSection(); ?>