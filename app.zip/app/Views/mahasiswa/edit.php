<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>
<h1>Edit Mahasiswa</h1>
<form action="/mahasiswa/update" method="post">
  <input type="hidden" name="id" value="<?= $mahasiswa['id']; ?>">
  <label>NIM</label><input type="text" name="nim" value="<?= $mahasiswa['nim']; ?>"><br>
  <label>Nama</label><input type="text" name="nama" value="<?= $mahasiswa['nama']; ?>"><br>
  <label>Prodi</label><input type="text" name="prodi" value="<?= $mahasiswa['prodi']; ?>"><br>
  <label>Universitas</label><input type="text" name="universitas" value="<?= $mahasiswa['universitas']; ?>"><br>
  <label>No HP</label><input type="text" name="no_hp" value="<?= $mahasiswa['no_hp']; ?>"><br>
  <button type="submit">Update</button>
</form>
<?= $this->endSection(); ?>