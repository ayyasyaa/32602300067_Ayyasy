<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<h2>Pengalaman dan Skill</h2>
<ul>
    <li>Web Developer dengan pengalaman Laravel dan CodeIgniter</li>
    <li>Mahir menggunakan Git dan Docker</li>
    <li>Aktif di komunitas crypto dan memahami trading dasar</li>
</ul>

<?= $this->endSection() ?>