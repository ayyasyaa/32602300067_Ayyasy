<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/halodunia', 'Page::halodunia');
$routes->match(['get','post'],'form','FormController::form');
$routes->post('process-form','FormController::processForm');
$routes->get('form', 'FormController::form');
$routes->post('submit', 'FormController::submit');
$routes->get('hello', 'Hello::index');
$routes->get('profil', 'Page::profil');
$routes->get('pengalaman', 'Page::pengalaman');
$routes->get('/layouting', 'LayoutingController');
$routes->get('/mahasiswa', 'MahasiswaController::index');
$routes->get('/mahasiswa/create', 'MahasiswaController::create');
$routes->post('/mahasiswa/store', 'MahasiswaController::store');
$routes->get('/mahasiswa/edit/(:num)', 'MahasiswaController::edit/$1');
$routes->post('/mahasiswa/update', 'MahasiswaController::update');
$routes->get('/mahasiswa/delete/(:num)', 'MahasiswaController::delete/$1');